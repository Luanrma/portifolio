/*window.onscroll = scroll;

function scroll() {
  let scrollTop = window.pageYOffset;
  
  if (scrollTop > 20) {
    document.querySelector('#navTop').id = 'navDown'
  } else {
    document.querySelector('#navDown').id = 'navTop'  
  }
}*/

window.addEventListener('scroll', function() {

	let scroll = window.pageYOffset;
	if (scroll > 20) {
		document.querySelector('#navTop').id = 'navDown'
	} else {
		document.querySelector('#navDown').id = 'navTop'  
	}
});