function Selecionar() {
    var card1 = document.querySelector('div#card1');
}